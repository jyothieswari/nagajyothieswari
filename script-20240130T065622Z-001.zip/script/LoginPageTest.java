package Pages;

import java.time.Duration;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginPageTest {

	 
		WebDriver driver;
		
		@BeforeTest
		public void LoginPageUIsetUp() 
		{
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		// Navigate to the Movies App website
		driver.get("https://qamoviesapp.ccbp.tech/login");
		driver.manage().window().maximize();
		
		
		}
		
		// Test the Login Page UI----------------------1.
		@Test
		public void LogoImage()
		{
			
		
		// logo image is displayed
		WebElement logoImage =driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[1]/img"));
		boolean isdisplayed = logoImage.isDisplayed();
		System.out.println("Logo is displayed");
		Assert.assertTrue(isdisplayed, "Logo image is not displayed on the website");
		
		}
		
		@Test
		public void verifyHeadingText()
		{
		// the Heading text is "Login"
		WebElement HeadingElement = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/form/h1"));
		String HeadingText = HeadingElement.getText();
		Assert.assertEquals(HeadingText, "Login", "Heading text is not 'Login'");
		
		}
		
		@Test
		public void testUsernameLabelText()
		{
			
		// the Username label text is "USERNAME"
		WebElement UsernameElement = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/form/div[1]/label"));
		String UsernameText = UsernameElement.getText();
		Assert.assertEquals(UsernameText, "USERNAME","Username label text doesn't match" );
		}
		
		@Test
		public void testPasswordLabelText()
		{
			
		
		//the Password label text is "PASSWORD"
		WebElement PasswordElement = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/form/div[2]/label"));
		String PasswordText = PasswordElement.getText();
		Assert.assertEquals(PasswordText, "PASSWORD","Password label text doesn't match");
		
		}
		
		@Test
		public void testLoginButton()
		{
			
		// the "Login" button
		
		WebElement LoginButton = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/form/div[2]/label"));
		Assert.assertTrue(LoginButton.isDisplayed(), "Login button is not displayed on the page");
		LoginButton.click();
		System.out.println("Login Button Clicked");
		}
		
		// Test the Login Page Functionalities---------2.
		
		@Test
		public void testLoginWithEmptyFields() throws InterruptedException
		{
			WebElement LoginButton = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/form/div[2]/label"));
			LoginButton.click();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
			WebElement errormessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[@class='error-message']")));
			//Thread.sleep(2000);
			//WebElement errormessage = driver.findElement(By.xpath("//p[@class='error-message']"));
			Assert.assertTrue(errormessage.getText().contains("Username or password is invalid"));
			// relative xpath -----------  //p[@class='error-message']			
		}
		
		@Test
		public void testLoginWithEmptyUsername()
		{
			WebElement passwordField  = driver.findElement(By.id("passwordInput"));
			passwordField.sendKeys("rahul@2021");
			
			WebElement LoginButton = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/form/div[2]/label"));
			LoginButton.click();
			// Get the error message element
			WebElement errormessage = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/form/p"));
			// Verify if the error message is displayed
			boolean isdisplayed = errormessage.isDisplayed();
			Assert.assertTrue(isdisplayed, "Error message for empty username not displayed.");
			
			Assert.assertEquals(isdisplayed, "Username or password is invalid", "Incorrect error message displayed.");
			
		}
		
		// login functionality with an empty PASSWORD
		@Test
		public void testLoginWithEmptyPassword()
		{
			WebElement usernameField  = driver.findElement(By.id("usernameInput"));
			usernameField.sendKeys("rahul");
			
			WebElement LoginButton = driver.findElement(By.className("login-button"));
			LoginButton.click();
			// Check if error message for empty password is displayed
			WebElement errormessage = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/form/p"));
			String actualErrorMessage  = errormessage.getText();
			String expectedErrorMessage = "Username or password is invalid";
			Assert.assertEquals(actualErrorMessage, expectedErrorMessage);
		}
		
		// with Invalid Credentials (correct username and wrong password),
		@Test
		public void testLoginWithInvalidCredentials()
		{
			WebElement usernameField  = driver.findElement(By.id("usernameInput"));
			usernameField.sendKeys("rahul");
			WebElement passwordField  = driver.findElement(By.id("passwordInput"));
			passwordField.sendKeys("rahul@20212");
			
			WebElement LoginButton = driver.findElement(By.xpath("//button[@class = 'login-button']"));
			LoginButton.click();
		}
		// login functionality with Valid Credentials,
		@Test
		public void testLoginWithvalidCredentials()
		{
			WebElement usernameField  = driver.findElement(By.id("usernameInput"));
			usernameField.sendKeys("rahul");
			WebElement passwordField  = driver.findElement(By.id("passwordInput"));
			passwordField.sendKeys("rahul@2021");
			
			WebElement LoginButton = driver.findElement(By.xpath("//button[@class = 'login-button']"));
			LoginButton.click();
			
			  // Verify redirected to homepageUrl 
			String actualURL = driver.getCurrentUrl(); 
			String expectedURL = "https://qamoviesapp.ccbp.tech/";
			Assert.assertEquals(actualURL,expectedURL);
			 
		}
		
		
		
		// Close the browser window.
		@AfterTest
		public void teardown()
		{
			if (driver!=null);
			{
				driver.quit();
			}
			
		}
				
		
	}

