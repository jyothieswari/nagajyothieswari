package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class PopularPageTest 
{
	WebDriver driver;
	@BeforeTest
	public void setup()
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("");
		driver.manage().window().maximize();
		
	}
	
	// Test whether the movies are displayed
	@Test
	public void testmoviesdisplayed()
	{
		List<WebElement> movieElements = driver.findElements(By.xpath("//a[@class,'link-item']"));
		// Assertion: Check if movies are displayed
		Assert.assertTrue(movieElements.size()>0, "Movies are displayed on the page");
	}
	
	@AfterTest
    public void teardown() {
        // Close the browser session
        if (driver != null) {
            driver.quit();
        }
    }
}
