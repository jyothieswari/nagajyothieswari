package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class HomePageTest 
{
	WebDriver driver;
	@BeforeTest
	public void URL() throws InterruptedException
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		// Navigate to the Movies App website
		driver.get("https://qamoviesapp.ccbp.tech/login");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		  
		 
	}
	
	// Test the heading texts of each section
	@Test
	public void testheadingtexts()
	{
		WebElement usernameField = driver.findElement(By.id("usernameInput"));
		  usernameField.sendKeys("rahul"); WebElement passwordField =
		  driver.findElement(By.id("passwordInput"));
		  passwordField.sendKeys("rahul@2021");
		  
		  WebElement LoginButton1 = driver.findElement(By.className("login-button"));
		  LoginButton1.click();
			
		System.out.println(driver.getCurrentUrl());
		driver.get("https://qamoviesapp.ccbp.tech/");
		
		  String[] sectiontags = {"h1"}; 
		  for(String tag : sectiontags)
		  {
		  WebElement headingElement = driver.findElement(By.tagName(tag)); 
		  String headingtext = headingElement.getText().trim();
		  Assert.assertFalse(headingtext.isEmpty(), "Heading text is empty for tag: "+tag);
		  System.out.println("Heading text for < " +tag+ "> is :- "+headingtext); 
		  }
	}
		  
		  // the play button is displayed or not
		@Test
		public void testplaybutton()
		{
		 WebElement playbuttonElement = driver.findElement(By.className("home-movie-play-button"));
		 boolean playbuttondisplayed = playbuttonElement.isDisplayed();
		 Assert.assertTrue(playbuttondisplayed, "Play button is not displayed");
	    }
		
		// the Movies are displayed, in the corresponding movies sections
		@Test
		public void testmoviessection()
		{
			String sectionName1 = "Trending Now";
			
			WebElement TrendingNow = driver.findElement(By.className("movies-list-heading"));
			List<WebElement> moviesInTrendingNowSection = TrendingNow.findElements(By.xpath(".//div[contains(@class, 'slick-slide')]"));
			Assert.assertTrue(moviesInTrendingNowSection.size()>0,"No movies found in the Action section.");
			System.out.println("Movies found in the Action section: " + moviesInTrendingNowSection.size());
			
			String sectionName2 = "Originals";
			
			WebElement Originals = driver.findElement(By.className("movies-list-heading"));
			List<WebElement> moviesInOriginalsSection = TrendingNow.findElements(By.xpath(".//div[contains(@class, 'slick-slide')]"));
			Assert.assertTrue(moviesInOriginalsSection.size()>0,"No movies found in the Action section.");
			System.out.println("Movies found in the Action section: " + moviesInOriginalsSection.size());
			
		}
		
		// Test the Contact Us Section
		@Test
		public void testcontactussection()
		{
			String[] socialMediaLinks = {"google","twitter","instagram","youtube"};
			for (String link :socialMediaLinks )
			{
				WebElement socialMediaElement  = driver.findElement(By.xpath(".//svg[contains(@class, ' "+link+" ')]"));
				socialMediaElement .click();
				Assert.assertTrue(socialMediaElement.isDisplayed(), "not displayed");
			}
			
		}
	
	// Close the browser window.
			@AfterTest
			public void teardown()
			{
				if (driver!=null);
				{
					driver.quit();
				}
			}
}

