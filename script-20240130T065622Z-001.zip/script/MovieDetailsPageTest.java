package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MovieDetailsPageTest 
{
	WebDriver driver;
	@BeforeTest
	public void setup()
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		// Navigate to the movie search page
		driver.get("");
		driver.manage().window().maximize();
		
	}
	/*In the Home Page click on any Movie and 
	test all the UI elements present in it*/
	@Test
	public void testHomepagemovieelements()
	{
		WebElement imageelement = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[1]/div/div/div/div/div[3]/div/a/div/img"));
		imageelement.click();
		String actualURL = driver.getCurrentUrl();
		String expectedURL = "https://qamoviesapp.ccbp.tech/movies/c6ef2389-078a-4117-b2dd-1dee027e5e8e";
		Assert.assertEquals(actualURL, expectedURL);
		
		// Find and assert content of h1 tag
		List<WebElement> h1tagElements = driver.findElements(By.tagName("h1"));
		for(WebElement h1tagElement : h1tagElements)
		{
			String h1tagText = h1tagElement.getText();
			System.out.println("Text in h1 tag: " + h1tagText);
			Assert.assertNotNull(h1tagText, "h1 tag not found on movie page");
			Assert.assertFalse(h1tagText.isEmpty(), "h1 tag text is empty");
		}
		
		// Find and assert content of p tag
		List<WebElement> ptagElements = driver.findElements(By.tagName("p"));
		for(WebElement ptagElement : ptagElements)
		{
			String ptagText = ptagElement.getText();
			System.out.println("Text in p tag: " + ptagText);
			Assert.assertNotNull(ptagText, "p tag not found on movie page");
			Assert.assertFalse(ptagText.isEmpty(), "p tag text is empty");
			
		}
		
	}

	
	
	@AfterTest
    public void teardown() {
        // Close the browser session
        if (driver != null) {
            driver.quit();
        }
    }
}
