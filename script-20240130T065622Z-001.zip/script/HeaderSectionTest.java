package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class HeaderSectionTest 
{
	WebDriver driver;
	
	@BeforeTest
	public void setup()
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		// Navigate to the website
		driver.get("https://qamoviesapp.ccbp.tech/");
		driver.manage().window().maximize();
		
	}
	
	// Test whether the Website logo is displayed
	@Test
	public void testWebsitelogo()
	{
		WebElement logoElement =driver.findElement(By.className("website-logo"));
		boolean logodisplayed = logoElement.isDisplayed();
		Assert.assertTrue(logodisplayed, "Logo image is not displayed");
	}
	
	// Test the Navbar elements
		@Test
		public void testNavbarElements()
		{
			List<WebElement> navbarElements = driver.findElements(By.xpath(".//div[@class = 'nav-content']/li"));
			for(int i=0;i<navbarElements.size(); i++)
			{
				WebElement Element = navbarElements.get(i);
				boolean Elementdisplayed = Element.isDisplayed();
				Assert.assertEquals(Elementdisplayed, "Not displayed" +(i+1)+"");
				Element.click();
				String pagetitle = driver.getTitle();
				System.out.println("Page title after clicking element"+ (i+1) +"is :- " +pagetitle);		
				// Navigate back to the main page for the next iteration
	            driver.navigate().back();
				
							
	         
			}
		}
		// Test the navigation to Home and Popular pages through elements in header section
		@Test
		public void testHomeandPopularpages()
		{
			// Assuming the navigation bar has links with specific IDs or classes
            WebElement homeLink = driver.findElement(By.className("home-container"));
         // Click on the elements and perform assertions
            homeLink.click();
            Assert.assertEquals(driver.getCurrentUrl(), "https://qamoviesapp.ccbp.tech/");
            
            WebElement popularLink = driver.findElement(By.className("nav-link"));
            popularLink.click();
            Assert.assertEquals(driver.getCurrentUrl(), "https://qamoviesapp.ccbp.tech/popular");

		}
		// Test the navigation to account page through elements in header section
		@Test
		public void testaccountpage()
		{
			WebElement accountelement = driver.findElement(By.className("avatar-img"));
			accountelement.click();
			Assert.assertEquals(driver.getCurrentUrl(), "https://qamoviesapp.ccbp.tech/account");
			
			
		}
		
		// Close the browser window
		@AfterTest
		public void tearDown() 
		{
	        if (driver != null) 
	        {
	            driver.quit();
		    }
		}
}
