package Pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SearchPageTest 
{
	WebDriver driver;
	@BeforeTest
	public void setup()
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		// Navigate to the movie search page
		driver.get("");
		driver.manage().window().maximize();
		
	}
	
	 /*Test the Search functionality by searching 
	 with some movie names and the count of movies displayed*/
	@Test
	public void testSearchfunctionalityandmoviescount()
	{
		// List of movie names to search
		String[] movienames = {"spider", "LUNA","Tita"};
		for(String moviename : movienames)
		{
			// Locate the search Button and click it
			WebElement searchemptybutton = driver.findElement(By.className("search-empty-button"));
			searchemptybutton.click();
			// Locate the search input field and enter the movie name
			WebElement Searchinput = driver.findElement(By.id("search"));
			Searchinput.clear();
			Searchinput.sendKeys(moviename);
			// Submit the search query
			WebElement searchbutton = driver.findElement(By.className("search-button"));
			searchbutton.click();
			// Wait for the search results to load 
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@class='search-movies-container']/li")));
			
			// Get the count of displayed movies
            int movieCount = driver.findElements(By.className("search-movies-container")).size(); 
            
            // Verify the count of displayed movies
            Assert.assertTrue(movieCount > 0, "No movies found for: " + moviename);
            System.out.println("Number of movies found for '" + moviename + "': " + movieCount);
        }
			
	}
    @AfterTest
    public void teardown() {
        // Close the browser session
        if (driver != null) {
            driver.quit();
        }
    }
	
	
		
}

